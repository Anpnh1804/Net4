﻿using ASM_NET4.Datas;
using Microsoft.AspNetCore.Mvc;

namespace ASM_NET4.Controllers
{
    public class LoginController : Controller
    {
        Net4DbContext db = new();
        public IActionResult Index()
        {
            ViewBag.ShowCheckCus = TempData["ShowCheckCus"];
            return View();
        }
        [HttpPost]
        public IActionResult Login(Customer cus)
        {
            var checkCus = db.Customers.FirstOrDefault(x=>x.CustomerName== cus.CustomerName && x.Pass == cus.Pass);
            if(checkCus != null)
            {
                HttpContext.Session.SetString("Name","A");
                return RedirectToAction("Index","Home");
            }
            TempData["ShowCheckCus"] = "NAME HOẶC PASS KHÔNG CHÍNH XÁC";
            return RedirectToAction("Index");


        }
    }
}
