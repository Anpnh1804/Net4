﻿using ASM_NET4.Datas;
using Microsoft.EntityFrameworkCore;

namespace ASM_NET4.Controllers
{
    
    public class FuntionS
    {
        Net4DbContext db = new();
        public int RandomID()
        {
            int maxId = db.Products.Select(p => p.ProductId).Max();

            int newId = maxId + 1;

            return newId;
        }
        public int RamdomCustomerID()
        {
            int maxId = db.Customers.Select(p => p.CustomerId).Max();

            int newId = maxId + 1;

            return newId;
        }
        public int RandomCartID()
        {

            List<Cart> carts = db.Carts.ToList();
            int maxId = carts.Any() ? carts.Max(p => p.CartId) : 0;
            int newId = maxId + 1;
            return newId;
        }
    }
}
