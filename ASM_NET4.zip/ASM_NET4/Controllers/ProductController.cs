﻿using ASM_NET4.Datas;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ASM_NET4.Controllers
{
    public class ProductController : Controller
    {
        FuntionS f = new();
        public ActionResult Index()
        {
            if (HttpContext.Session.GetString("Name") != null)
            {
                List<Product> products = db.Products.ToList();
                return View(products);               
            }
            ViewBag.ShowCheckCus = "VUI LÒNG ĐĂNG NHẬP!";
            return RedirectToAction("Index", "Login");
        }
        Net4DbContext db = new();
        [HttpPost]
        public IActionResult AddProduct(Product model)
        {
            if (ModelState.IsValid)
            {
                var newProduct = new Product
                {
                    ProductId = f.RandomID(),
                    ProductName = model.ProductName,
                    CategoryId = model.CategoryId,
                    Price = model.Price,
                    Picture = "~/IMG/riuthor.png",
                    Description = model.Description
                };


                db.Products.Add(newProduct);
                db.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(model);
        }

        [HttpPost]
        public IActionResult EditProduct(Product model)
        {
            if (ModelState.IsValid)
            {

                var productEdit = db.Products
                                .Where(x => x.ProductName == model.ProductName)
                                .FirstOrDefault();
                if(productEdit != null)
                {
                    productEdit.ProductName = model.ProductName;
                    productEdit.CategoryId = model.CategoryId;
                    productEdit.Price = model.Price;
                    productEdit.Description = model.Description;
                    db.SaveChanges();

                }

                return RedirectToAction("Index");
            }

            return View(model);
        }
        [HttpPost]
        public IActionResult RemoveProduct(Product model)
        {
            if (ModelState.IsValid)
            {
                var productRemove = db.Products.FirstOrDefault(x => x.ProductName == model.ProductName);
                                                
                if(productRemove != null)
                {
                    db.Remove(productRemove);
                    db.SaveChanges();
                }
                return RedirectToAction("Index");
            }

            return View(model);
        }

    }
}
