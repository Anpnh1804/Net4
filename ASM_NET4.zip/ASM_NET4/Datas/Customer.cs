﻿using System;
using System.Collections.Generic;

namespace ASM_NET4.Datas;

public partial class Customer
{
    public int CustomerId { get; set; }

    public string? CustomerName { get; set; }

    public string? Email { get; set; }

    public string? Address { get; set; }

    public string? Pass { get; set; }

    public virtual ICollection<Cart> Carts { get; set; } = new List<Cart>();
}
